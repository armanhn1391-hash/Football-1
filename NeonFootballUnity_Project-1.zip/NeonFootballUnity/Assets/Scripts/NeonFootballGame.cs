using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class NeonFootballGame : MonoBehaviour
{
    public static NeonFootballGame Instance;

    [Header("Match")]
    public float matchLengthSeconds = 180f;
    public float fieldHalfWidth = 34f;
    public float fieldHalfLength = 50f;

    private readonly List<FootballPlayer> homePlayers = new List<FootballPlayer>();
    private readonly List<FootballPlayer> awayPlayers = new List<FootballPlayer>();
    private FootballPlayer controlled;
    private Rigidbody ballBody;
    private Transform ballTransform;
    private Camera gameCamera;
    private Canvas canvas;
    private Text scoreText, timerText, messageText;
    private Text selectedText;
    private float timeLeft;
    private int homeScore, awayScore;
    private bool paused;
    private float messageTimer;
    private Vector2 joystick;
    private bool sprintHeld;
    private bool shootHeld;
    private bool passPressed, tacklePressed, switchPressed;
    private Vector3 ballStart;

    private readonly Color homeColor = new Color(0.05f, 0.52f, 0.95f);
    private readonly Color awayColor = new Color(0.92f, 0.19f, 0.20f);
    private readonly Color grassColor = new Color(0.10f, 0.40f, 0.20f);
    private readonly Dictionary<Color, Material> materialCache = new Dictionary<Color, Material>();

    void Awake()
    {
        Instance = this;
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;
        QualitySettings.antiAliasing = 0;
        QualitySettings.shadows = ShadowQuality.HardOnly;
        QualitySettings.shadowResolution = ShadowResolution.Low;
        timeLeft = matchLengthSeconds;
        BuildWorld();
        BuildTeams();
        BuildUI();
        SelectPlayer(homePlayers[9]);
        ShowMessage("NEON FOOTBALL 3D  |  KICK OFF!", 3f);
    }

    void Update()
    {
        if (paused) return;
        if (timeLeft > 0f)
        {
            timeLeft -= Time.deltaTime;
            if (timeLeft <= 0f) { timeLeft = 0f; paused = true; ShowMessage("FULL TIME!", 999f); }
        }
        UpdateInput();
        UpdateAI();
        UpdateCamera();
        UpdateHUD();
        if (messageTimer > 0f) messageTimer -= Time.deltaTime;
        if (messageText != null) messageText.enabled = messageTimer > 0f;
        if (ballTransform != null) CheckBallBoundsAndGoals();
    }

    void FixedUpdate()
    {
        if (paused || controlled == null || ballBody == null) return;
        MoveControlled();
        if (!passPressed && !shootHeld && !tacklePressed) MaintainDribble();
        if (passPressed) { DoPass(); passPressed = false; }
        if (shootHeld) { DoShoot(); shootHeld = false; }
        if (tacklePressed) { DoTackle(); tacklePressed = false; }
        if (switchPressed) { SwitchPlayer(); switchPressed = false; }
        KeepBallOnPitch();
    }

    void BuildWorld()
    {
        RenderSettings.ambientLight = new Color(0.55f, 0.58f, 0.62f);
        RenderSettings.fog = false;
        gameObject.name = "NeonFootballGame";

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Pitch";
        ground.transform.position = new Vector3(0, -0.55f, 0);
        ground.transform.localScale = new Vector3(fieldHalfWidth * 2f + 8f, 1f, fieldHalfLength * 2f + 8f);
        ground.GetComponent<Renderer>().material = MakeMat(grassColor);

        GameObject field = GameObject.CreatePrimitive(PrimitiveType.Cube);
        field.name = "PlayingSurface";
        field.transform.position = new Vector3(0, -0.02f, 0);
        field.transform.localScale = new Vector3(fieldHalfWidth * 2f, 0.08f, fieldHalfLength * 2f);
        field.GetComponent<Renderer>().material = MakeMat(new Color(0.12f, 0.46f, 0.22f));

        CreateLine(new Vector3(0, 0.035f, 0), new Vector3(fieldHalfWidth * 2f, 0.04f, 0.13f));
        CreateLine(new Vector3(0, 0.035f, -fieldHalfLength), new Vector3(fieldHalfWidth * 2f, 0.04f, 0.13f));
        CreateLine(new Vector3(0, 0.035f, fieldHalfLength), new Vector3(fieldHalfWidth * 2f, 0.04f, 0.13f));
        CreateLine(new Vector3(-fieldHalfWidth, 0.035f, 0), new Vector3(0.13f, 0.04f, fieldHalfLength * 2f));
        CreateLine(new Vector3(fieldHalfWidth, 0.035f, 0), new Vector3(0.13f, 0.04f, fieldHalfLength * 2f));
        CreateLine(new Vector3(0, 0.04f, 0), new Vector3(fieldHalfWidth * 2f, 0.035f, 0.13f));
        CreateCircle(new Vector3(0, 0.05f, 0), 9.2f, 64);
        CreateCircle(new Vector3(0, 0.05f, -fieldHalfLength + 11f), 9.2f, 48);
        CreateCircle(new Vector3(0, 0.05f, fieldHalfLength - 11f), 9.2f, 48);
        CreateBoxMarkings(-fieldHalfLength + 16f);
        CreateBoxMarkings(fieldHalfLength - 16f);
        CreateSpot(new Vector3(0, 0.07f, -fieldHalfLength + 11f));
        CreateSpot(new Vector3(0, 0.07f, fieldHalfLength - 11f));
        CreateGoals();
        CreateStadium();
        CreateLighting();

        GameObject camObj = new GameObject("Broadcast Camera");
        gameCamera = camObj.AddComponent<Camera>();
        gameCamera.fieldOfView = 52f;
        gameCamera.nearClipPlane = 0.1f;
        gameCamera.farClipPlane = 250f;
        gameCamera.allowHDR = false;
        gameCamera.allowMSAA = false;
        gameCamera.transform.position = new Vector3(0, 28f, -31f);
        gameCamera.transform.LookAt(new Vector3(0, 0, 2f));
        AudioListener listener = camObj.AddComponent<AudioListener>();
    }

    void BuildTeams()
    {
        // 4-4-2 shape, goalkeeper + 10 outfield players for each team.
        float[,] positions = new float[11, 2] {
            {0,-44}, {-23,-28}, {-8,-30}, {8,-30}, {23,-28}, {-19,-10}, {-6,-12}, {6,-12}, {19,-10}, {-9,-1}, {9,-1}
        };
        for (int i = 0; i < 11; i++)
        {
            Vector3 p = new Vector3(positions[i, 0], 0, positions[i, 1]);
            FootballPlayer h = CreatePlayer("Home " + (i + 1), true, i, p, homeColor);
            homePlayers.Add(h);
            Vector3 q = new Vector3(-positions[i, 0], 0, -positions[i, 1]);
            FootballPlayer a = CreatePlayer("Away " + (i + 1), false, i, q, awayColor);
            awayPlayers.Add(a);
        }
        ballStart = new Vector3(0, 0.42f, -1.2f);
        // Put the kickoff striker beside the ball so the first touch is immediately playable.
        homePlayers[9].homePosition = new Vector3(0, 0, -2.6f);
        homePlayers[9].transform.position = homePlayers[9].homePosition;
        GameObject ball = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        ball.name = "Match Ball";
        ball.transform.position = ballStart;
        ball.transform.localScale = Vector3.one * 0.72f;
        ball.GetComponent<Renderer>().material = MakeMat(Color.white);
        ballBody = ball.AddComponent<Rigidbody>();
        ballBody.mass = 0.43f;
        ballBody.useGravity = false;
        ballBody.drag = 0.7f;
        ballBody.angularDrag = 0.25f;
        ballBody.interpolation = RigidbodyInterpolation.Interpolate;
        ballBody.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        ballTransform = ball.transform;
    }

    FootballPlayer CreatePlayer(string playerName, bool home, int index, Vector3 pos, Color shirt)
    {
        GameObject root = new GameObject(playerName);
        root.transform.position = pos;
        FootballPlayer fp = root.AddComponent<FootballPlayer>();
        fp.Init(this, home, index, pos);
        GameObject body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        body.name = "PlayerBody";
        body.transform.SetParent(root.transform, false);
        body.transform.localPosition = new Vector3(0, 1f, 0);
        body.transform.localScale = new Vector3(0.72f, 0.82f, 0.72f);
        body.GetComponent<Renderer>().material = MakeMat(shirt);
        Destroy(body.GetComponent<Collider>());
        GameObject head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        head.name = "Head";
        head.transform.SetParent(root.transform, false);
        head.transform.localPosition = new Vector3(0, 2.03f, 0);
        head.transform.localScale = Vector3.one * 0.42f;
        head.GetComponent<Renderer>().material = MakeMat(new Color(0.78f, 0.61f, 0.45f));
        Destroy(head.GetComponent<Collider>());
        GameObject shorts = GameObject.CreatePrimitive(PrimitiveType.Cube);
        shorts.name = "Shorts";
        shorts.transform.SetParent(root.transform, false);
        shorts.transform.localPosition = new Vector3(0, 0.49f, 0);
        shorts.transform.localScale = new Vector3(0.75f, 0.38f, 0.55f);
        shorts.GetComponent<Renderer>().material = MakeMat(new Color(0.08f, 0.1f, 0.15f));
        Destroy(shorts.GetComponent<Collider>());
        GameObject marker = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        marker.name = "Selection Marker";
        marker.transform.SetParent(root.transform, false);
        marker.transform.localPosition = new Vector3(0, 0.08f, 0);
        marker.transform.localScale = new Vector3(1.1f, 0.018f, 1.1f);
        marker.GetComponent<Renderer>().material = MakeMat(new Color(0.1f, 1f, 0.65f));
        Destroy(marker.GetComponent<Collider>());
        fp.marker = marker;
        marker.SetActive(false);
        return fp;
    }

    void CreateGoals()
    {
        float z1 = -fieldHalfLength - 0.65f;
        float z2 = fieldHalfLength + 0.65f;
        CreateGoalAt(z1, -1);
        CreateGoalAt(z2, 1);
    }

    void CreateGoalAt(float z, int side)
    {
        float w = 7.4f, h = 2.7f;
        Color c = Color.white;
        CreatePost(new Vector3(-w / 2f, h / 2f, z), new Vector3(0.22f, h, 0.22f), c);
        CreatePost(new Vector3(w / 2f, h / 2f, z), new Vector3(0.22f, h, 0.22f), c);
        CreatePost(new Vector3(0, h, z), new Vector3(w, 0.22f, 0.22f), c);
        CreatePost(new Vector3(-w / 2f, h / 2f, z + side * 1.7f), new Vector3(0.12f, h, 0.12f), new Color(0.85f, 0.88f, 0.9f));
        CreatePost(new Vector3(w / 2f, h / 2f, z + side * 1.7f), new Vector3(0.12f, h, 0.12f), new Color(0.85f, 0.88f, 0.9f));
        CreatePost(new Vector3(0, h, z + side * 1.7f), new Vector3(w, 0.12f, 0.12f), new Color(0.85f, 0.88f, 0.9f));
    }

    void CreatePost(Vector3 pos, Vector3 scale, Color color)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.transform.position = pos;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().material = MakeMat(color);
    }

    void CreateBoxMarkings(float z)
    {
        float sign = Mathf.Sign(z);
        float outerZ = z - sign * 5f;
        CreateLine(new Vector3(0, 0.04f, outerZ), new Vector3(40f, 0.035f, 0.12f));
        CreateLine(new Vector3(-20f, 0.04f, z), new Vector3(0.12f, 0.035f, 10f));
        CreateLine(new Vector3(20f, 0.04f, z), new Vector3(0.12f, 0.035f, 10f));
        float smallZ = z - sign * 1.5f;
        CreateLine(new Vector3(0, 0.04f, smallZ), new Vector3(20f, 0.035f, 0.12f));
        CreateLine(new Vector3(-10f, 0.04f, z), new Vector3(0.12f, 0.035f, 3f));
        CreateLine(new Vector3(10f, 0.04f, z), new Vector3(0.12f, 0.035f, 3f));
    }

    void CreateCircle(Vector3 center, float radius, int points)
    {
        for (int i = 0; i < points; i++)
        {
            float a = (float)i / points * Mathf.PI * 2f;
            float b = (float)(i + 1) / points * Mathf.PI * 2f;
            Vector3 p1 = center + new Vector3(Mathf.Cos(a) * radius, 0, Mathf.Sin(a) * radius);
            Vector3 p2 = center + new Vector3(Mathf.Cos(b) * radius, 0, Mathf.Sin(b) * radius);
            CreateLineBetween(p1, p2, 0.11f);
        }
    }

    void CreateSpot(Vector3 p)
    {
        GameObject s = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        s.transform.position = p;
        s.transform.localScale = new Vector3(0.45f, 0.025f, 0.45f);
        s.GetComponent<Renderer>().material = MakeMat(Color.white);
        Destroy(s.GetComponent<Collider>());
    }

    void CreateLine(Vector3 center, Vector3 scale)
    {
        GameObject line = GameObject.CreatePrimitive(PrimitiveType.Cube);
        line.transform.position = center;
        line.transform.localScale = scale;
        line.GetComponent<Renderer>().material = MakeMat(new Color(0.9f, 0.94f, 0.9f));
        Destroy(line.GetComponent<Collider>());
    }

    void CreateLineBetween(Vector3 a, Vector3 b, float width)
    {
        Vector3 d = b - a;
        GameObject line = GameObject.CreatePrimitive(PrimitiveType.Cube);
        line.transform.position = (a + b) * 0.5f;
        line.transform.localScale = new Vector3(width, 0.035f, d.magnitude);
        line.transform.rotation = Quaternion.LookRotation(d);
        line.GetComponent<Renderer>().material = MakeMat(new Color(0.9f, 0.94f, 0.9f));
        Destroy(line.GetComponent<Collider>());
    }

    void CreateStadium()
    {
        // Low-cost stands made from a few large colored tiers.
        for (int i = 0; i < 3; i++)
        {
            float y = 1.4f + i * 1.25f;
            GameObject north = GameObject.CreatePrimitive(PrimitiveType.Cube);
            north.transform.position = new Vector3(0, y, fieldHalfLength + 8.5f + i * 0.25f);
            north.transform.localScale = new Vector3(86f, 2f, 2.2f);
            north.GetComponent<Renderer>().material = MakeMat(i % 2 == 0 ? new Color(0.09f, 0.12f, 0.2f) : new Color(0.14f, 0.18f, 0.28f));
            GameObject south = GameObject.CreatePrimitive(PrimitiveType.Cube);
            south.transform.position = new Vector3(0, y, -fieldHalfLength - 8.5f - i * 0.25f);
            south.transform.localScale = north.transform.localScale;
            south.GetComponent<Renderer>().material = north.GetComponent<Renderer>().material;
            GameObject left = GameObject.CreatePrimitive(PrimitiveType.Cube);
            left.transform.position = new Vector3(-fieldHalfWidth - 8.5f - i * 0.25f, y, 0);
            left.transform.localScale = new Vector3(2.2f, 2f, 116f);
            left.GetComponent<Renderer>().material = north.GetComponent<Renderer>().material;
            GameObject right = GameObject.CreatePrimitive(PrimitiveType.Cube);
            right.transform.position = new Vector3(fieldHalfWidth + 8.5f + i * 0.25f, y, 0);
            right.transform.localScale = left.transform.localScale;
            right.GetComponent<Renderer>().material = north.GetComponent<Renderer>().material;
        }
        // Simple stadium roof beams.
        foreach (float x in new float[] { -45f, 45f })
        {
            GameObject beam = GameObject.CreatePrimitive(PrimitiveType.Cube);
            beam.transform.position = new Vector3(x, 10f, 0);
            beam.transform.localScale = new Vector3(1f, 1f, 115f);
            beam.GetComponent<Renderer>().material = MakeMat(new Color(0.08f, 0.1f, 0.15f));
        }
    }

    void CreateLighting()
    {
        GameObject sun = new GameObject("Stadium Sun");
        Light l = sun.AddComponent<Light>();
        l.type = LightType.Directional;
        l.intensity = 1.05f;
        l.shadows = LightShadows.Soft;
        sun.transform.rotation = Quaternion.Euler(48f, -28f, 0f);
        foreach (Vector3 p in new Vector3[] { new Vector3(-43, 16, -43), new Vector3(43, 16, -43), new Vector3(-43, 16, 43), new Vector3(43, 16, 43) })
        {
            GameObject lamp = new GameObject("Floodlight");
            lamp.transform.position = p;
            Light spot = lamp.AddComponent<Light>();
            spot.type = LightType.Point;
            spot.range = 28f;
            spot.intensity = 2.2f;
            spot.shadows = LightShadows.None;
            spot.color = new Color(0.72f, 0.84f, 1f);
        }
    }

    Material MakeMat(Color color)
    {
        Material cached;
        if (materialCache.TryGetValue(color, out cached) && cached != null) return cached;
        Shader shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Diffuse");
        Material m = new Material(shader);
        m.color = color;
        materialCache[color] = m;
        return m;
    }

    void BuildUI()
    {
        GameObject es = new GameObject("EventSystem");
        es.AddComponent<EventSystem>();
        es.AddComponent<StandaloneInputModule>();
        GameObject canvasObj = new GameObject("Game Canvas");
        canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObj.AddComponent<CanvasScaler>().uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        canvasObj.GetComponent<CanvasScaler>().referenceResolution = new Vector2(1600, 900);
        canvasObj.GetComponent<CanvasScaler>().matchWidthOrHeight = 0.5f;
        canvasObj.AddComponent<GraphicRaycaster>();

        scoreText = MakeText("Score", "BLUE  0  -  0  RED", 34, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -35), new Vector2(440, 60), TextAnchor.MiddleCenter);
        timerText = MakeText("Timer", "03:00", 26, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -87), new Vector2(170, 46), TextAnchor.MiddleCenter);
        messageText = MakeText("Message", "", 32, new Vector2(0.5f, 0.68f), new Vector2(0.5f, 0.68f), Vector2.zero, new Vector2(900, 80), TextAnchor.MiddleCenter);
        messageText.color = new Color(1f, 0.9f, 0.25f);
        selectedText = MakeText("PlayerName", "PLAYER 10", 20, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0, 18), new Vector2(260, 42), TextAnchor.MiddleCenter);

        GameObject joy = MakePanel("JoystickZone", new Vector2(0, 0), new Vector2(0, 0), new Vector2(150, 150), new Vector2(128, 125), new Color(0.05f, 0.08f, 0.12f, 0.30f));
        JoystickTouch jt = joy.AddComponent<JoystickTouch>();
        GameObject knob = MakePanel("JoystickKnob", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, 0), new Vector2(55, 55), new Color(0.15f, 0.85f, 0.75f, 0.85f));
        knob.transform.SetParent(joy.transform, false);
        jt.knob = knob.GetComponent<RectTransform>();

        MakeActionButton("PASS", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-255, 125), new Vector2(112, 74), new Color(0.12f, 0.55f, 0.95f, 0.85f), ActionButton.Action.Pass);
        MakeActionButton("SHOOT", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-125, 205), new Vector2(120, 82), new Color(0.95f, 0.27f, 0.16f, 0.9f), ActionButton.Action.Shoot);
        MakeActionButton("SPRINT", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-125, 92), new Vector2(105, 64), new Color(0.12f, 0.68f, 0.4f, 0.85f), ActionButton.Action.Sprint);
        MakeActionButton("TACKLE", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-385, 90), new Vector2(105, 64), new Color(0.55f, 0.3f, 0.8f, 0.85f), ActionButton.Action.Tackle);
        MakeActionButton("SWITCH", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-385, 170), new Vector2(105, 64), new Color(0.22f, 0.26f, 0.35f, 0.9f), ActionButton.Action.Switch);
        MakeActionButton("PAUSE", new Vector2(1, 1), new Vector2(1, 1), new Vector2(-72, -55), new Vector2(110, 56), new Color(0.08f, 0.1f, 0.16f, 0.8f), ActionButton.Action.Pause);
        MakeText("Hint", "MOVE: WASD / LEFT STICK     PASS: E     SHOOT: SPACE", 16, new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 72), new Vector2(740, 34), TextAnchor.MiddleCenter).color = new Color(1, 1, 1, 0.75f);
    }

    GameObject MakePanel(string name, Vector2 amin, Vector2 amax, Vector2 offset, Vector2 size, Color color)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(canvas.transform, false);
        RectTransform rt = go.AddComponent<RectTransform>();
        rt.anchorMin = amin; rt.anchorMax = amax; rt.anchoredPosition = offset; rt.sizeDelta = size;
        Image img = go.AddComponent<Image>(); img.color = color;
        return go;
    }

    Text MakeText(string name, string value, int size, Vector2 amin, Vector2 amax, Vector2 offset, Vector2 dimensions, TextAnchor anchor)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(canvas.transform, false);
        RectTransform rt = go.AddComponent<RectTransform>();
        rt.anchorMin = amin; rt.anchorMax = amax; rt.anchoredPosition = offset; rt.sizeDelta = dimensions;
        Text t = go.AddComponent<Text>();
        t.text = value; t.font = Resources.GetBuiltinResource<Font>("Arial.ttf"); t.fontSize = size;
        t.alignment = anchor; t.color = Color.white; t.fontStyle = FontStyle.Bold;
        t.horizontalOverflow = HorizontalWrapMode.Overflow; t.verticalOverflow = VerticalWrapMode.Overflow;
        t.supportRichText = false;
        return t;
    }

    void MakeActionButton(string label, Vector2 amin, Vector2 amax, Vector2 offset, Vector2 size, Color color, ActionButton.Action action)
    {
        GameObject go = MakePanel(label + "Button", amin, amax, offset, size, color);
        ActionButton ab = go.AddComponent<ActionButton>(); ab.action = action;
        Text t = MakeText(label + "Label", label, 19, new Vector2(0, 0), new Vector2(1, 1), Vector2.zero, Vector2.zero, TextAnchor.MiddleCenter);
        t.transform.SetParent(go.transform, false);
        RectTransform tr = t.GetComponent<RectTransform>(); tr.anchorMin = Vector2.zero; tr.anchorMax = Vector2.one; tr.offsetMin = Vector2.zero; tr.offsetMax = Vector2.zero;
    }

    void UpdateInput()
    {
        Vector2 keyboard = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        if (keyboard.sqrMagnitude > 0.01f) joystick = Vector2.ClampMagnitude(keyboard, 1f);
        if (Input.GetKeyDown(KeyCode.E)) passPressed = true;
        if (Input.GetKeyDown(KeyCode.Space)) shootHeld = true;
        if (Input.GetKeyDown(KeyCode.LeftShift)) sprintHeld = true;
        if (Input.GetKeyUp(KeyCode.LeftShift)) sprintHeld = false;
        if (Input.GetKeyDown(KeyCode.Q)) switchPressed = true;
        if (Input.GetKeyDown(KeyCode.F)) tacklePressed = true;
        if (Input.GetKeyDown(KeyCode.Escape)) TogglePause();
    }

    void MoveControlled()
    {
        Vector3 forward = gameCamera.transform.forward; forward.y = 0; forward.Normalize();
        Vector3 right = gameCamera.transform.right; right.y = 0; right.Normalize();
        Vector3 dir = right * joystick.x + forward * joystick.y;
        if (dir.sqrMagnitude > 1f) dir.Normalize();
        float speed = sprintHeld ? 9.2f : 6.2f;
        Vector3 next = controlled.transform.position + dir * speed * Time.fixedDeltaTime;
        next.x = Mathf.Clamp(next.x, -fieldHalfWidth + 1f, fieldHalfWidth - 1f);
        next.z = Mathf.Clamp(next.z, -fieldHalfLength + 1f, fieldHalfLength - 1f);
        controlled.transform.position = new Vector3(next.x, 0, next.z);
        if (dir.sqrMagnitude > 0.02f) controlled.transform.rotation = Quaternion.Slerp(controlled.transform.rotation, Quaternion.LookRotation(dir), 12f * Time.fixedDeltaTime);
    }

    void UpdateAI()
    {
        if (ballTransform == null) return;
        UpdateTeamAI(homePlayers, true);
        UpdateTeamAI(awayPlayers, false);
    }

    void UpdateTeamAI(List<FootballPlayer> team, bool isHome)
    {
        for (int i = 0; i < team.Count; i++)
        {
            FootballPlayer p = team[i];
            if (p == controlled) continue;
            Vector3 pos = p.transform.position;
            Vector3 ball = ballTransform.position;
            float distance = Vector3.Distance(new Vector3(pos.x, 0, pos.z), new Vector3(ball.x, 0, ball.z));
            bool defending = (isHome && ball.z > 0) || (!isHome && ball.z < 0);
            Vector3 target = p.homePosition;
            if (distance < (i == 0 ? 18f : 12f) || (defending && distance < 23f))
            {
                target = new Vector3(ball.x + (i % 2 == 0 ? 1.5f : -1.5f), 0, ball.z + (isHome ? -1.5f : 1.5f));
            }
            else if (Mathf.Abs(ball.x) > 11f && i % 3 == 0)
            {
                target.x = Mathf.Lerp(target.x, ball.x * 0.5f, 0.55f);
                target.z += isHome ? 3f : -3f;
            }
            float speed = distance < 13f ? 5.8f : 3.0f;
            Vector3 delta = target - pos; delta.y = 0;
            if (delta.magnitude > 0.65f)
            {
                Vector3 step = delta.normalized * speed * Time.deltaTime;
                if (step.magnitude > delta.magnitude) step = delta;
                p.transform.position += step;
                if (step.sqrMagnitude > 0.001f) p.transform.rotation = Quaternion.Slerp(p.transform.rotation, Quaternion.LookRotation(step), 7f * Time.deltaTime);
            }
            if (distance < 1.45f && ballBody.velocity.magnitude < 11f)
            {
                Vector3 attack = isHome ? Vector3.forward : Vector3.back;
                ballBody.AddForce((attack + Vector3.up * 0.04f) * 2.6f, ForceMode.Acceleration);
            }
        }
    }


    void MaintainDribble()
    {
        if (controlled == null || ballBody == null) return;
        Vector3 player = controlled.transform.position;
        float distance = Vector3.Distance(new Vector3(player.x, 0, player.z), new Vector3(ballTransform.position.x, 0, ballTransform.position.z));
        // Softly keep a slow ball near the selected player's leading foot.
        if (distance < 1.65f && ballBody.velocity.magnitude < 5.5f)
        {
            Vector3 desired = player + controlled.transform.forward * 1.05f + Vector3.up * 0.38f;
            ballTransform.position = Vector3.Lerp(ballTransform.position, desired, 0.35f);
            ballBody.velocity = Vector3.zero;
        }
    }

    void DoPass()
    {
        if (controlled == null) return;
        if (Vector3.Distance(controlled.transform.position, ballTransform.position) > 3.8f)
        { ShowMessage("MOVE CLOSER TO THE BALL", 0.8f); return; }
        FootballPlayer target = null;
        float bestScore = -9999f;
        Vector3 attackDir = controlled.isHome ? Vector3.forward : Vector3.back;
        foreach (FootballPlayer p in (controlled.isHome ? homePlayers : awayPlayers))
        {
            if (p == controlled) continue;
            Vector3 delta = p.transform.position - controlled.transform.position;
            float distance = delta.magnitude;
            if (distance < 1f || distance > 32f) continue;
            float forward = Vector3.Dot(delta.normalized, attackDir);
            float score = forward * 17f - distance * 0.35f;
            if (score > bestScore) { bestScore = score; target = p; }
        }
        Vector3 dir;
        if (target != null)
        {
            Vector3 targetPoint = target.transform.position + (controlled.isHome ? Vector3.forward : Vector3.back) * 1.0f;
            dir = (targetPoint - ballTransform.position).normalized;
        }
        else dir = controlled.transform.forward;
        KickBall(dir, 10.5f, 1.2f);
        ShowMessage("PASS!", 0.7f);
    }

    void DoShoot()
    {
        if (controlled == null) return;
        if (Vector3.Distance(controlled.transform.position, ballTransform.position) > 3.8f)
        { ShowMessage("MOVE CLOSER TO THE BALL", 0.8f); return; }
        Vector3 goal = new Vector3(0, 0.45f, controlled.isHome ? fieldHalfLength + 4f : -fieldHalfLength - 4f);
        Vector3 dir = (goal - ballTransform.position).normalized;
        float aim = Mathf.Clamp(controlled.transform.position.x * -0.025f, -0.28f, 0.28f);
        dir = (dir + controlled.transform.right * aim + Vector3.up * 0.12f).normalized;
        KickBall(dir, 19f, 2.1f);
        ShowMessage("SHOT!", 0.7f);
    }

    void KickBall(Vector3 direction, float force, float lift)
    {
        if (Vector3.Distance(controlled.transform.position, ballTransform.position) > 3.4f)
        {
            direction = (ballTransform.position - controlled.transform.position + controlled.transform.forward * 0.4f).normalized;
        }
        ballBody.velocity = Vector3.zero;
        ballBody.angularVelocity = Vector3.zero;
        ballBody.AddForce(direction * force + Vector3.up * lift, ForceMode.VelocityChange);
    }

    void DoTackle()
    {
        FootballPlayer nearest = null;
        float best = 2.8f;
        foreach (FootballPlayer p in awayPlayers)
        {
            float d = Vector3.Distance(controlled.transform.position, p.transform.position);
            if (d < best) { best = d; nearest = p; }
        }
        if (nearest != null)
        {
            Vector3 pop = controlled.isHome ? Vector3.forward : Vector3.back;
            ballBody.velocity = pop * 6.5f + Vector3.up * 1.1f;
            ShowMessage("GOOD TACKLE!", 0.8f);
        }
        else ShowMessage("GET CLOSER!", 0.6f);
    }

    void SwitchPlayer()
    {
        FootballPlayer best = null;
        float distance = float.MaxValue;
        foreach (FootballPlayer p in homePlayers)
        {
            if (p == controlled) continue;
            float d = Vector3.Distance(p.transform.position, ballTransform.position);
            if (d < distance) { distance = d; best = p; }
        }
        if (best != null) SelectPlayer(best);
    }

    void SelectPlayer(FootballPlayer p)
    {
        if (controlled != null && controlled.marker != null) controlled.marker.SetActive(false);
        controlled = p;
        if (controlled.marker != null) controlled.marker.SetActive(true);
        if (selectedText != null) selectedText.text = controlled.playerName;
    }

    void UpdateCamera()
    {
        if (controlled == null || gameCamera == null) return;
        Vector3 target = controlled.transform.position;
        Vector3 desired = target + new Vector3(0, 25f, -27f);
        gameCamera.transform.position = Vector3.Lerp(gameCamera.transform.position, desired, 4f * Time.deltaTime);
        gameCamera.transform.rotation = Quaternion.Slerp(gameCamera.transform.rotation, Quaternion.LookRotation((target + new Vector3(0, 0, 5f)) - gameCamera.transform.position), 4f * Time.deltaTime);
    }

    void KeepBallOnPitch()
    {
        Vector3 p = ballTransform.position;
        if (p.y < 0.36f) { p.y = 0.36f; ballTransform.position = p; if (ballBody.velocity.y < 0) ballBody.velocity = new Vector3(ballBody.velocity.x, 0, ballBody.velocity.z); }
        if (Mathf.Abs(p.x) > fieldHalfWidth + 2f || Mathf.Abs(p.z) > fieldHalfLength + 2f)
        {
            ballBody.velocity *= 0.25f;
        }
    }

    void CheckBallBoundsAndGoals()
    {
        Vector3 p = ballTransform.position;
        bool inGoalX = Mathf.Abs(p.x) < 3.8f;
        if (inGoalX && p.z > fieldHalfLength + 0.1f && p.y < 3f)
        {
            homeScore++; GoalReset("GOAL FOR BLUE!");
        }
        else if (inGoalX && p.z < -fieldHalfLength - 0.1f && p.y < 3f)
        {
            awayScore++; GoalReset("GOAL FOR RED!");
        }
        else if (Mathf.Abs(p.x) > fieldHalfWidth + 1f || Mathf.Abs(p.z) > fieldHalfLength + 4f)
        {
            ballBody.velocity = Vector3.zero;
            ballTransform.position = ballStart;
        }
    }

    void GoalReset(string message)
    {
        paused = true;
        ballBody.velocity = Vector3.zero;
        ballBody.angularVelocity = Vector3.zero;
        ballTransform.position = ballStart;
        for (int i = 0; i < homePlayers.Count; i++) homePlayers[i].transform.position = homePlayers[i].homePosition;
        for (int i = 0; i < awayPlayers.Count; i++) awayPlayers[i].transform.position = awayPlayers[i].homePosition;
        ShowMessage(message + "  |  TAP TO CONTINUE", 3f);
        Invoke("ResumeAfterGoal", 2.1f);
    }

    void ResumeAfterGoal() { if (timeLeft > 0) paused = false; }

    void UpdateHUD()
    {
        if (scoreText != null) scoreText.text = "BLUE  " + homeScore + "  -  " + awayScore + "  RED";
        int sec = Mathf.CeilToInt(timeLeft);
        if (timerText != null) timerText.text = (sec / 60).ToString("00") + ":" + (sec % 60).ToString("00");
        if (selectedText != null && controlled != null) selectedText.text = controlled.playerName;
    }

    void ShowMessage(string text, float duration)
    {
        if (messageText != null) { messageText.text = text; messageText.enabled = true; }
        messageTimer = duration;
    }

    public void SetJoystick(Vector2 value) { joystick = Vector2.ClampMagnitude(value, 1f); }
    public void SetSprint(bool value) { sprintHeld = value; }
    public void Trigger(ActionButton.Action action)
    {
        if (action == ActionButton.Action.Pass) passPressed = true;
        else if (action == ActionButton.Action.Shoot) shootHeld = true;
        else if (action == ActionButton.Action.Tackle) tacklePressed = true;
        else if (action == ActionButton.Action.Switch) switchPressed = true;
        else if (action == ActionButton.Action.Pause) TogglePause();
    }

    void TogglePause()
    {
        paused = !paused;
        ShowMessage(paused ? "PAUSED  |  TAP PAUSE TO RESUME" : "PLAY!", 1.8f);
    }
}

public class FootballPlayer : MonoBehaviour
{
    public NeonFootballGame game;
    public bool isHome;
    public int index;
    public Vector3 homePosition;
    public GameObject marker;
    public string playerName;

    public void Init(NeonFootballGame owner, bool home, int number, Vector3 start)
    {
        game = owner; isHome = home; index = number; homePosition = start;
        playerName = (home ? "BLUE " : "RED ") + (number + 1);
    }
}

public class JoystickTouch : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    public RectTransform knob;
    private RectTransform rect;
    private float radius = 55f;
    void Awake() { rect = GetComponent<RectTransform>(); }
    public void OnPointerDown(PointerEventData e) { OnDrag(e); }
    public void OnDrag(PointerEventData e)
    {
        Vector2 local;
        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(rect, e.position, e.pressEventCamera, out local))
        {
            Vector2 value = Vector2.ClampMagnitude(local / radius, 1f);
            if (knob != null) knob.anchoredPosition = value * radius;
            if (NeonFootballGame.Instance != null) NeonFootballGame.Instance.SetJoystick(value);
        }
    }
    public void OnPointerUp(PointerEventData e)
    {
        if (knob != null) knob.anchoredPosition = Vector2.zero;
        if (NeonFootballGame.Instance != null) NeonFootballGame.Instance.SetJoystick(Vector2.zero);
    }
}

public class ActionButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public enum Action { Pass, Shoot, Sprint, Tackle, Switch, Pause }
    public Action action;
    public void OnPointerDown(PointerEventData e)
    {
        if (NeonFootballGame.Instance == null) return;
        if (action == Action.Sprint) NeonFootballGame.Instance.SetSprint(true);
        else NeonFootballGame.Instance.Trigger(action);
    }
    public void OnPointerUp(PointerEventData e)
    {
        if (action == Action.Sprint && NeonFootballGame.Instance != null) NeonFootballGame.Instance.SetSprint(false);
    }
}
