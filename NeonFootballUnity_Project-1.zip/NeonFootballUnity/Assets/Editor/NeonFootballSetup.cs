using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEditor.Build;

public static class NeonFootballSetup
{
    private const string ScenePath = "Assets/Scenes/Main.unity";

    [MenuItem("Neon Football/1 - Create Main Scene")]
    public static void CreateMainScene()
    {
        if (!Directory.Exists("Assets/Scenes")) Directory.CreateDirectory("Assets/Scenes");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        GameObject root = new GameObject("NEON FOOTBALL 3D");
        root.AddComponent<NeonFootballGame>();
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        ConfigureAndroid();
        AssetDatabase.SaveAssets();
        Debug.Log("Neon Football scene created. Press Play to test, or use Neon Football > 2 - Build Android APK.");
    }

    [MenuItem("Neon Football/2 - Build Android APK")]
    public static void BuildAndroidAPK()
    {
        if (!File.Exists(ScenePath)) CreateMainScene();
        ConfigureAndroid();
        string output = Path.GetFullPath("Build/NeonFootball.apk");
        Directory.CreateDirectory(Path.GetDirectoryName(output));
        BuildPlayerOptions options = new BuildPlayerOptions();
        options.scenes = new[] { ScenePath };
        options.locationPathName = output;
        options.target = BuildTarget.Android;
        options.options = BuildOptions.None;
        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result == BuildResult.Succeeded)
            Debug.Log("APK built successfully: " + output + " | Size: " + report.summary.totalSize + " bytes");
        else
            Debug.LogError("APK build failed. Check Console and install Android Build Support (SDK, NDK, OpenJDK) in Unity Hub.");
    }

    [MenuItem("Neon Football/3 - Create Scene + Build APK")]
    public static void CreateAndBuild() { CreateMainScene(); BuildAndroidAPK(); }

    private static void ConfigureAndroid()
    {
        PlayerSettings.productName = "Neon Football 3D";
        PlayerSettings.companyName = "Neon Studio";
        PlayerSettings.bundleVersion = "1.0.0";
        PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.neonstudio.neonfootball3d");
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
        PlayerSettings.allowedAutorotateToLandscapeLeft = true;
        PlayerSettings.allowedAutorotateToLandscapeRight = true;
        PlayerSettings.allowedAutorotateToPortrait = false;
        PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel23;
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
        PlayerSettings.stripEngineCode = true;
        PlayerSettings.SetManagedStrippingLevel(BuildTargetGroup.Android, ManagedStrippingLevel.Medium);
        QualitySettings.SetQualityLevel(0, true);
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
    }

}
