@echo off
setlocal
set UNITY_EXE=C:\Program Files\Unity\Hub\Editor\2022.3.62f1\Editor\Unity.exe
if not exist "%UNITY_EXE%" (
  echo Unity Editor not found at:
  echo %UNITY_EXE%
  echo Install Unity 2022.3 LTS with Android Build Support, Android SDK and NDK, and OpenJDK.
  pause
  exit /b 1
)
if not exist "%~dp0Build" mkdir "%~dp0Build"
"%UNITY_EXE%" -batchmode -quit -projectPath "%~dp0" -executeMethod NeonFootballSetup.CreateAndBuild -logFile "%~dp0Build\unity-build.log"
if exist "%~dp0Build\NeonFootball.apk" (
  echo.
  echo APK ready: %~dp0Build\NeonFootball.apk
) else (
  echo Build did not produce an APK. Check Build\unity-build.log.
)
pause
