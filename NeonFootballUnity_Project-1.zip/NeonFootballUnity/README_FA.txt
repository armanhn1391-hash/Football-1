NEON FOOTBALL 3D — پروژه Unity برای اندروید
نسخه پروژه: Unity 2022.3 LTS | رندر Built-in | بدون نیاز به فایل گرافیکی خارجی

محتویات
- مسابقه سه‌بعدی با ۲۲ بازیکن
- زمین فوتبال، دروازه‌ها، خطوط و سکوهای ساده استادیوم
- دوربین دنبال‌کننده با زاویه نزدیک به پخش تلویزیونی
- کنترل لمسی: جوی‌استیک، پاس، شوت، دویدن سرعتی، تکل، تعویض بازیکن و مکث
- کنترل کیبورد برای تست در ادیتور
- ساخت خودکار صحنه و تنظیمات Android از منوی Unity

نحوه باز کردن پروژه
1) Unity Hub را نصب و اجرا کن.
2) از بخش Installs، نسخه Unity 2022.3 LTS را نصب کن و حتماً این موارد را انتخاب کن:
   Android Build Support
   Android SDK & NDK Tools
   OpenJDK
3) از Projects > Add، پوشه NeonFootballUnity را انتخاب کن.
4) پروژه را با Unity 2022.3 باز کن.
5) از منوی بالای Unity گزینه Neon Football > 1 - Create Main Scene را بزن.
6) برای تست، دکمه Play را بزن.
7) برای APK، گزینه Neon Football > 2 - Build Android APK را بزن.
8) خروجی در پوشه Build با نام NeonFootball.apk ساخته می‌شود.

نکته مهم
این محیط ساخت، Unity Editor و Android SDK/NDK ندارد؛ بنابراین APK در اینجا کامپایل نشده است.
پروژه شامل کد و ابزار ساخت صحنه/APK است، اما قبل از انتشار باید در Unity باز و روی گوشی تست شود.

کنترل‌ها در Editor
WASD یا فلش‌ها: حرکت
E: پاس
Space: شوت
Left Shift: سرعت
F: تکل
Q: تعویض بازیکن
Escape: مکث

کنترل‌ها در موبایل
جوی‌استیک پایین چپ: حرکت
PASS: پاس
SHOOT: شوت
SPRINT: دویدن سرعتی (تا وقتی انگشت نگه داشته شود)
TACKLE: تکل
SWITCH: انتخاب بازیکن نزدیک‌تر به توپ
PAUSE: مکث/ادامه

شناسه برنامه Android: com.neonstudio.neonfootball3d
حداقل Android API: 23
معماری خروجی: ARM64
حالت صفحه: افقی
